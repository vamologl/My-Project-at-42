/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   user.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vamologl <vamologl@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/06 13:24:07 by vamologl          #+#    #+#             */
/*   Updated: 2024/05/27 15:37:43 by vamologl         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "include/minishell.h"

char	*correct_place(char *s)
{
	char	*ret;
	int		i;
	int		j;
	int		k;

	i = 0;
	j = 0;
	while (s && s[i] != 47)
		i++;
	i++;
	k = i;
	while (s && s[k] != '.')
	{
		j++;
		k++;
	}
	ret = ft_sstrndup(s, j, i, -1);
	return (ret);
}

char	*get_correct_path_path2(char *path, int count, int k)
{
	int		i;
	int		j;
	char	*ret;

	i = 0;
	j = 0;
	while (path[i] && j < 3)
	{
		if (path[i] == '/')
			j++;
		i++;
	}
	i--;
	while (k <= i)
		k++;
	k = i;
	while (path && path[k])
	{
		count++;
		k++;
	}
	ret = ft_sstrndup(path, count, i, 2);
	ret = ft_strjoin_gc("~", ret, 2);
	return (ret);
}

char	*get_correct_path(void)
{
	char	*path;
	char	*ret;
	int		count;
	int		k;

	k = 0;
	count = 0;
	path = return_pwd();
	if (hm_that_char(path, '/') == 2)
		return ("");
	else if (hm_that_char(path, '/') < 2)
		return (path);
	else
	{
		ret = get_correct_path_path2(path, count, k);
		return (ret);
	}
}

char	*create_string_user(t_base *base)
{
	char	*user;
	char	*manage;
	char	*tmp;
	char	*tmp2;

	tmp2 = get_correct_path();
	user = get_var_env(base->env_old, "USER");
	manage = get_var_env(base->env_old, "SESSION_MANAGER");
	if (ft_strcmp(user, "\a\0") == 0 || ft_strcmp(manage, "\a\0") == 0)
		return (NULL);
	manage = correct_place(manage);
	tmp = ft_strjoin_gc(user, "@", 2);
	tmp = ft_strjoin_gc(tmp, manage, 2);
	tmp = ft_strjoin_gc(tmp, ":", 2);
	tmp = ft_strjoin_gc(tmp, tmp2, 2);
	tmp = ft_strjoin_gc(tmp, "$ ", 2);
	return (tmp);
}

void	init_user(t_base *base)
{
	char	*ret;

	ret = create_string_user(base);
	if (!ret)
		base->user = ft_strjoin_gc("minishell@c0r0p0", ":~$ ", 2);
	else
		base->user = ret;
}
