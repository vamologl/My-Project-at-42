/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   gest_struct.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vamologl <vamologl@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/17 13:04:32 by vamologl          #+#    #+#             */
/*   Updated: 2024/06/07 10:24:54 by vamologl         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "include/minishell.h"

volatile int	g_return_code;

void	init_path(t_base *base)
{
	char	*strtmp;

	strtmp = ft_strjoin_gc("OLDPWD=", return_pwd(), 2);
	update_env_old(base, strtmp);
	strtmp = ft_strjoin_gc("PWD=", return_pwd(), 2);
	update_env_old(base, strtmp);
}

void	get_heredoc(t_base *base)
{
	char	*tmp;

	tmp = get_var_env(base->env_old, "PWD");
	tmp = ft_strjoin_gc(tmp, "/Utils/.tmp", 2);
	base->path_heredoc = tmp;
}

void	init_base(t_base *base, char **env)
{
	g_return_code = 0;
	base->tableau = NULL;
	base->tableau = gc_alloc((sizeof(char ***) * 1024), 1);
	base->input = NULL;
	base->user = NULL;
	base->cur_pwd = NULL;
	base->env_old = env;
	base->output_file = NULL;
	base->command = NULL;
	base->terminal_in = dup(1);
	base->terminal_out = dup(0);
	base->fd_in = dup(1);
	base->fd_out = dup(0);
	base->env_path = NULL;
	base->flag_redir = 0;
	base->return_value_flag = 0;
	base->loop = 0;
	base->tablen = 0;
	base->flag_error_redir = 0;
	base->dl_redir_check_break = 0;
	base->error_parse = 0;
	base->here_doc = 0;
	get_heredoc(base);
}

void	gest_shlvl(t_base *base)
{
	int		tmp;
	int		i;
	char	*tmp2;

	i = 0;
	tmp2 = get_var_env(base->env_old, "SHLVL");
	tmp = ft_atoi(tmp2);
	tmp++;
	tmp2 = ft_itoa_gc(tmp, 4);
	while (base->env_old && base->env_old[i])
	{
		if (ft_strncmp(base->env_old[i], "SHLVL=", 6) == 0)
		{
			base->env_old[i] = ft_strjoin_gc("SHLVL=", tmp2, 4);
			return ;
		}
		i++;
	}
}

void	check_loop_start(t_base *base)
{
	dup2(base->terminal_in, base->fd_in);
	dup2(base->terminal_out, base->fd_out);
	base->heredoc_error = 0;
	base->flag_error_redir = 0;
	if (base->loop == 0)
		g_return_code = 0;
	if (g_return_code == 134)
		g_return_code = 131;
	init_user(base);
}
