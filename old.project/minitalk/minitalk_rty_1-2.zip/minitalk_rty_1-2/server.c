/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   maintest.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vamologl <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/17 09:10:12 by vamologl          #+#    #+#             */
/*   Updated: 2023/08/17 09:10:55 by vamologl         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "include/minitalk.h"

static int	g_receive = -1;

void	received_signal(int n)
{
	if (n == SIGUSR1)
		g_receive = 0;
	else if (n == SIGUSR2)
		g_receive = 1;
	else if (n == SIGINT)
	{
		ft_printf("|exit|");
		exit(2);
	}
}

char	receive_byte(void)
{
	char	c;
	int		count;

	c = 0;
	count = 0;
	while (1)
	{
		while (g_receive == -1)
			continue ;
		c += g_receive;
		g_receive = -1;
		if (++count == 8)
			return (c);
		else
			c <<= 1;
	}
}

int	main(void)
{
	struct sigaction	sa;
	static char			c;
	static char			*str = NULL;

	ft_printf("Server PID: %u\n", getpid());
	sa.sa_handler = received_signal;
	sigemptyset(&sa.sa_mask);
	sa.sa_flags = 0;
	sigaction(SIGUSR1, &sa, NULL);
	sigaction(SIGUSR2, &sa, NULL);
	sigaction(SIGINT, &sa, NULL);
	while (1)
	{
		if (!str)
			str = (char *)malloc(sizeof(char) + 1);
		c = receive_byte();
		if (ft_isprint(c))
			str = ft_strjoin(str, &c);
		else if (c == '\0')
		{
			ft_printf("%s\n", str);
			free(str);
		}
	}
}
